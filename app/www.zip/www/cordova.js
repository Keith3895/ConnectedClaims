// This is a placeholder file to stop 404 errors.  
// When creating an app with VS2015, the cordova.js is overwritten during the build process.